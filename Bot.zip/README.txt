	BY STARTING AND RUNNING THIS DISCORD BOT YOU AGREE TO THE OFFICIAL DISCORD TERMS OF SERVICE (https://discord.com/terms) AND YOU AGREE TO THAT
						YOU HAVE READ THOSE TERMS, UNDERSTAND AND KNOW THEM!
	YOU ALSO AGREE TO NOT USE THIS BOT IN ANY HARMFULL OR MALICIOUS WAY THAT VIOLATES THE TOS AND THAT IF YOU DO THAT THE CREATOR OF THIS BOT
					     IS NOT RESPONSIBLE IN ANY WAY AND CAN NOT BE SUED FOR ANYTHING!!
					YOU TAKE FULL RESPONSIBILITY FOR ANY OF YOUR ACTIONS REGARDING THIS BOT!!
					     THIS IS A LEGAL DOCUMENT AND AGGREMENT THAT WILL COUNT IN COURT!!!


How to start the bot:
0. Install and setup python latest version on your computer.
1. Make a new aplication at the Discord Developer Portal (https://discord.com/developers/applications).
2. Set everything up (I'm not gonna explain all that just watch one of the few hundred YouTube Tutorial on that topic).
3. Invite the Bot to your Server (Again, watch some tutorial).
4. Put your Bot Token in THE FIRST LINE of the "config.txt" file without any of the "" or '' just the blank token in the FIRST line.
5. Save the file.
6. Open the file called "bot.exe" or if your anti-virus doesn't allow it "start-bot.bat" make sure to NOT open it with notepad.
7. Click through the process, have fun with the bot, add custom command or change commands as you want/need.
Notice: The bot is only online while you are running it, it's not permanent.
You see everything that is happening with the bot in the terminal and everything also gets saved in the "log.txt" file.