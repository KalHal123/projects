import discord
from discord.ext import commands
import random as ra
import os

DISCORD_API_TOKEN = 'o'
script_directory = os.path.dirname(os.path.abspath(__file__))
config_file_path = os.path.join(script_directory, 'config.txt')

with open(config_file_path, 'r') as file:
    DISCORD_API_TOKEN = file.readline().strip()

# Print or use the value as needed
if DISCORD_API_TOKEN:
    print("> TOKEN FOUND!")
else:
    print("> Error: Unable to read DISCORD_API_TOKEN from config.txt.")

def run():
    log_list = []
    def write_to_log_file(log_text):
        with open('log.txt', 'a') as file:
            file.write(log_text + '\n')
    def update_and_write_to_log(new_item):
        log_list.append(new_item)
        write_to_log_file(new_item)
        log_list.clear()
    intents = discord.Intents.default()
    intents.message_content = True
    discord.Intents.all()
    
    bot = commands.Bot(command_prefix="!",intents=intents)
    
    @bot.event
    async def on_ready():
        print("-----------------------------------------------------------------------------------")
        print(f"| Bot: {bot.user} with ID: {bot.user.id} is now ready, up and running! |")
        print("-----------------------------------------------------------------------------------")
        update_and_write_to_log("-----------------------------------------------------------------------------------")
        update_and_write_to_log(f"| Bot: {bot.user} with ID: {bot.user.id} is now ready, up and running! |")
        update_and_write_to_log("-----------------------------------------------------------------------------------")
    @bot.command(
        aliases=['p','pi','ping-pong','pingpong','ping_pong'],
        help="This is a custom bot that is still under development if you have any questions or want to report any bugs should ask a moderator",
        brief="-- Answers with pong",
        description="-- Answers with pong"
        )
    async def ping(ctx):
        print(f"> {ctx.message.author} with id {ctx.message.author.id} used the !ping command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} ")
        await ctx.send(f"<@{ctx.message.author.id}> **pong**")
        update_and_write_to_log(f"> {ctx.message.author} with id {ctx.message.author.id} used the !ping command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} ")
        update_and_write_to_log(f"> Bot said: <@{ctx.message.author.id}> **pong**")
    @bot.command(
        aliases=['c','choose','chooserandom'],
        help="This is a custom bot that is still under development if you have any questions or want to report any bugs should ask a moderator",
        brief="-- Chooses one of the given words/numbers",
        description="-- Chooses one of the given words/numbers seperated with spaces"
    )
    async def roll_a_dice(ctx, *choices):
        print(f"> {ctx.message.author} with id {ctx.message.author.id} used the !roll command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} ")
        rchoice = ra.choice(choices)
        await ctx.send(f"<@{ctx.message.author.id}>, I chose {rchoice}!")
        update_and_write_to_log(f"> {ctx.message.author} with id {ctx.message.author.id} used the !roll command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} ")
        update_and_write_to_log(f"> Bot said: <@{ctx.message.author.id}>, I chose {rchoice}!")
    @bot.command(
        aliases=['k','kick','kick-member','kick-user','kick_member'],
        help="This is a custom bot that is still under development if you have any questions or want to report any bugs should ask a moderator",
        brief="-- Kicks a member, parameters needed: Username, Reason",
        description="-- Kicks user, parameters needed: 1. Username, 2. Reason"
    )
    @commands.has_permissions(kick_members=True)
    async def kick_user(ctx,member:discord.Member,*,reason=None):
        print(f"> {ctx.message.author} with id {ctx.message.author.id} used the !kick command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} ")
        if reason == None:
            reason="no reason provided"
        await ctx.guild.kick(member)
        await ctx.send(f"**<@{ctx.message.author.id}>, {member.mention} Has been kicked for {reason}!**")
        update_and_write_to_log(f"> {ctx.message.author} with id {ctx.message.author.id} used the !kick command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} |")
        update_and_write_to_log(f"> Bot said: **<@{ctx.message.author.id}>, {member.mention} Has been kicked for {reason}!**")
        print(f"> Member {member} has been kicked for reason {reason} by member {ctx.message.author} id: {ctx.message.author.id}")
        update_and_write_to_log(f"> Member {member} has been kicked for reason {reason} by member {ctx.message.author} id: {ctx.message.author.id}")
    @bot.command(
        aliases=['b','ban','ban-member','ban-user','ban_member'],
        help="This is a custom bot that is still under development if you have any questions or want to report any bugs should ask a moderator",
        brief="-- Bans a member, parameters needed: Username, Reason",
        description="-- Bans user, parameters needed: 1. Username, 2. Reason"
    )
    @commands.has_permissions(ban_members=True)
    async def ban_user(ctx,member:discord.Member,*,reason=None):
        print(f"> {ctx.message.author} with id {ctx.message.author.id} used the !ban command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} |")
        if reason == None:
            reason="no reason provided"
        await ctx.guild.ban(member)
        await ctx.send(f"**<@{ctx.message.author.id}>, {member.mention} Has been banned for {reason}!**")
        update_and_write_to_log(f"> {ctx.message.author} with id {ctx.message.author.id} used the !ban command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content}")
        update_and_write_to_log(f"> Bot said: **<@{ctx.message.author.id}>, {member.mention} Has been banned for {reason}!**")
        print(f"> Member {member} has been banned for reason {reason} by member {ctx.message.author} id: {ctx.message.author.id}")
        update_and_write_to_log(f"> Member {member} has been banned for reason {reason} by member {ctx.message.author} id: {ctx.message.author.id}")
    @bot.command(
        aliases=['w','who','whoisthis'],
        help="This is a custom bot that is still under development if you have any questions or want to report any bugs should ask a moderator",
        brief="-- Gives information about a member",
        description="-- Gives information about a member for example when they joined"
    )
    async def who_is_this(ctx,user: discord.Member):
        print(f"> {ctx.message.author} with id {ctx.message.author.id} used the !who command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} ")
        await ctx.send(f"""
        <@{ctx.message.author.id}>
        Sure, here is some information about {user}!
        Name: **{user}**
        User-ID: **{user.id}**
        Joined at: **{user.joined_at}**
        Roles: **{user._roles}**
        Client status: **{user._client_status}**
        More?: **{user.is_on_mobile}**
        """)
        update_and_write_to_log(f"> {ctx.message.author} with id {ctx.message.author.id} used the !who command in channel {ctx.message.channel} in message {ctx.message.id} saying: {ctx.message.content} ")
        update_and_write_to_log(f"""
        > Bot said:
        > <@{ctx.message.author.id}>
        > Sure, here is some information about {user}!
        > Name: **{user}**
        > User-ID: **{user.id}**
        > Joined at: **{user.joined_at}**
        > Roles: **{user._roles}**
        > Client status: **{user._client_status}**
        > More?: **{user.is_on_mobile}**
        """)
    bot.run(DISCORD_API_TOKEN)
run()